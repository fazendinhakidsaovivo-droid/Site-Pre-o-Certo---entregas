// Função serverless da Vercel: recebe a foto de uma oferta e devolve os produtos lidos pelo Claude.
// Variáveis de ambiente necessárias na Vercel:
//   ANTHROPIC_API_KEY  (obrigatória)
//   CLAUDE_MODEL       (opcional; padrão abaixo)

const PROMPT_OFERTA =
  'Você lê fotos de ofertas e encartes de supermercado brasileiro. Responda SOMENTE JSON, sem markdown, ' +
  'neste formato: {"itens":[{"nome":"nome do produto sem marca nem peso","marca":"marca impressa ou vazio",' +
  '"peso":"peso ou volume impresso, ex: 1kg, 900ml; vazio se não houver","preco":preço da oferta em reais como número,' +
  '"preco_de":preço antigo em reais como número ou null,"bbox":[x0,y0,x1,y1]}]}. ' +
  'bbox é a área da FOTO do produto (sem o preço e sem o texto), em frações da largura e altura da imagem inteira, ' +
  'entre 0 e 1. Liste somente produtos com preço visível.';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ erro: 'Use POST' });
  }

  const chave = process.env.ANTHROPIC_API_KEY;
  if (!chave) {
    return res.status(500).json({ erro: 'ANTHROPIC_API_KEY não configurada na Vercel' });
  }

  const { imagem, tipo = 'image/jpeg' } = req.body || {};
  if (typeof imagem !== 'string' || imagem.length === 0) {
    return res.status(400).json({ erro: 'Envie a foto em base64 no campo "imagem"' });
  }
  if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(tipo)) {
    return res.status(400).json({ erro: 'Tipo de imagem não suportado' });
  }

  const resposta = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': chave,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: process.env.CLAUDE_MODEL || 'claude-sonnet-5-5',
      max_tokens: 2000,
      system: PROMPT_OFERTA,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: tipo, data: imagem } },
            { type: 'text', text: 'Extraia as ofertas desta foto.' },
          ],
        },
      ],
    }),
  });

  const dados = await resposta.json();
  if (!resposta.ok) {
    return res.status(502).json({ erro: dados?.error?.message || 'Falha ao chamar a API do Claude' });
  }

  const texto = (dados.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  let itens;
  try {
    itens = JSON.parse(texto.replace(/```json|```/g, '').trim());
  } catch {
    return res.status(502).json({ erro: 'Resposta do Claude não estava em JSON', bruto: texto });
  }

  return res.status(200).json(itens);
}
